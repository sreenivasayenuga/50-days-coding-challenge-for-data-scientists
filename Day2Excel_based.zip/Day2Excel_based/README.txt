The raw dataset has 205 rows (including header), but after processing, we'll see it's 200 unique records. Columns: Student_ID (int), Age (int), Study_Hours (float), Screen_Time (float), Test_Scores (float), Extra_Curricular_Hours (float). Issues include missing values (blanks as empty strings) and duplicates (e.g., rows for Student_ID 132, 46, 129, 24, 39 repeated at the end).
1. Data Cleaning
Goal: Fix inaccuracies for reliable analysis.

Import the Data into Excel:

Copy the CSV content into a text editor, save as .csv, then open in Excel (File > Open > Browse).
Or paste directly into a new sheet "Raw Data" starting at A1.
Output: 205 rows x 6 columns. Excel treats blanks as empty cells.


Identify and Handle Missing Values:

Select A1:F206 (entire data).
Go to Home > Conditional Formatting > Highlight Cells Rules > More Rules > Format only cells that contain "Blanks" > Apply color (e.g., yellow) to spot them.
Count: Use formulas like =COUNTBLANK(B2:B206) for each column.
Results (from computation): 6 missing in Study_Hours, 6 in Screen_Time, 6 in Test_Scores (none in others).
Handle: Fill with column averages (impute). In Excel:

Calculate averages: In a helper row (e.g., G2: =AVERAGEIF(B2:B206,"<>""",B2:B206) for Study_Hours, ignoring blanks. Results: Study_Hours ~2.45, Screen_Time ~4.05, Test_Scores ~71.07.
Use Find & Replace or formulas: Select blanks (Home > Find & Select > Go To Special > Blanks), then type =AVERAGE above and Ctrl+Enter to fill.


Alternative: Delete rows with many misses, but here we impute to retain data.
Output: No missing values remain. Example affected rows:

Row 5 (Student_ID 5): Study_Hours filled with ~2.45.
Row 13 (Student_ID 13): Screen_Time filled with ~4.05.
Row 38 (Student_ID 38): Test_Scores filled with ~71.07.


Remove Duplicate Records:

Select A1:F206.
Data > Remove Duplicates > Select all columns > OK.
Excel prompts: "5 duplicate values found and removed; 200 unique values remain."
Output: Dataset now 200 rows (duplicates like Student_ID 132, 46, etc., removed).


Ensure Consistent Formatting:

Select columns B:F.
Home > Number > Format as "Number" with 1 decimal place.
For any text-like numbers: Data > Text to Columns > Delimited > Finish (converts to numeric).
Fix negatives: Extra_Curricular_Hours in Student_ID 100 is -0.0; use Find & Replace to change to 0.0 if invalid (assuming typo).
Output: All columns numeric. Cleaned dataset (excerpt, first 5 rows post-cleaning):


Student_IDAgeStudy_HoursScreen_TimeTest_ScoresExtra_Curricular_Hours1162.52.775.01.62172.74.068.10.73153.04.367.91.54173.02.847.21.85172.451.878.01.4
Save this in a new sheet "Cleaned Data".
2. Data Transformation
Add derived fields for deeper analysis.

Create New Calculated Fields:

In "Cleaned Data", add column G: "Screen_Time_Category".
In G2: =IF(D2>4, "High (>4 hrs)", "Low (<=4 hrs)"), drag down.
Add column H: "Age_Group" with =IF(B2<=15, "15 or under", "16+"), drag down.
Output: Flags applied to all 200 rows. Excerpt (first 5 rows):


Student_ID...Screen_Time...Screen_Time_CategoryAge_Group1...2.7...Low (<=4 hrs)16+2...4.0...Low (<=4 hrs)16+3...4.3...High (>4 hrs)15 or under4...2.8...Low (<=4 hrs)16+5...1.8...Low (<=4 hrs)16+
3. Pivot Tables
Summarize data in a new sheet "Pivot Tables".

Insert Pivot Table:

Select "Cleaned Data" range > Insert > PivotTable > New Worksheet > OK.


Average Test Scores by Screen Time Category:

Rows: Screen_Time_Category; Values: Average of Test_Scores.
Output:


Screen_Time_CategoryAverage of Test_ScoresHigh (>4 hrs)72.20Low (<=4 hrs)69.49Grand Total70.68

Screen Time vs. Extracurricular Activity Trends:

Rows: Screen_Time_Category; Values: Average of Extra_Curricular_Hours.
Output:



Screen_Time_CategoryAverage of Extra_Curricular_HoursHigh (>4 hrs)1.61Low (<=4 hrs)1.46Grand Total1.52

Age Group-wise Performance:

Rows: Age_Group; Values: Average of Test_Scores.
Output:



Age_GroupAverage of Test_Scores15 or under71.8216+69.68Grand Total70.68
4. Charts & Dashboards
Visualize in a new sheet "Dashboard".

Scatter Plot of Screen Time vs. Test Scores:

Select columns D and E (Screen_Time and Test_Scores) from "Cleaned Data".
Insert > Charts > Scatter > Scatter with Markers.
Add trendline: Right-click points > Add Trendline > Linear (display equation/R²).
Title: "Screen Time vs. Test Scores".
Output Description: Points show weak positive correlation (r ≈ 0.14). Screen time ranges 0.0–7.9 hours; scores 34.3–100.0. Trendline slopes slightly upward, e.g., from ~68 at 0 hrs to ~73 at 8 hrs, but scattered— no strong drop with higher screen time.


Bar Chart Comparing Average Test Scores Across Screen Time Ranges:

Use the first pivot table.
Select it > Insert > Charts > Bar > Clustered Bar.
Title: "Average Test Scores by Screen Time Category".
Output Description: Two bars: "Low (<=4 hrs)" at 69.49, "High (>4 hrs)" at 72.20. Surprisingly, high screen time bar is slightly taller, indicating minor positive association.


Dashboard Setup:

Arrange pivots and charts on one sheet.
Add slicers: Insert > Slicer > "Age_Group" or "Screen_Time_Category" for interactive filtering.



5. Insights & Reporting
Based on the analysis, summarize in 3-5 bullet points (place in a new sheet "Insights" or a Word doc). The data shows a weak positive (not negative) relationship between screen time and scores, contrary to common assumptions—perhaps due to productive screen use (e.g., educational apps) or other factors.

Students with high screen time (>4 hours) have an average test score of 72.20, which is about 4% higher than those with low screen time (69.49), suggesting minimal or even slightly positive impact from screen time in this dataset.
The scatter plot reveals a weak positive correlation (r ≈ 0.14) between screen time and test scores, with no clear drop in performance as screen time increases; scores vary widely (34–100) across all screen time levels (0–8 hours).
Students with high screen time spend slightly more time on extracurricular activities (average 1.61 hours vs. 1.46 hours for low), indicating high screen users may balance activities better or use screens for non-disruptive purposes.
Younger students (15 or under) outperform older ones (71.82 vs. 69.68 average scores), but screen time doesn't exacerbate gaps; recommend investigating other factors like study hours (average ~2.45) for targeted support.
Actionable Recommendation: Since screen time doesn't strongly harm performance here, focus on quality over quantity—e.g., promote educational screen use while monitoring extremes (e.g., >7 hours).